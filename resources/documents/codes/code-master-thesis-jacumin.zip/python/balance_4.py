import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemLOD import DiffusionProblemLOD
from util import norm

u_0 = lambda X: np.zeros(np.prod(X+1))
f = lambda X: np.ones(np.prod(X+1))

# Mesh
nu = 0.00001
Cs = [0.5]
nCoarses = range(200, 210)
# problem setting
alpha = 1
beta  = 1.

for C in Cs:
	print(C)
	delta_Ts = np.zeros(len(nCoarses))
	for i in range(0, len(nCoarses)):
		nCoarse = nCoarses[i]
		NCoarse = np.array([nCoarse,nCoarse])
		NFine = 2*NCoarse
		
		N = int(C*nCoarse)

		problemLOD = DiffusionProblemLOD(NFine, NCoarse)
		problemLOD.generateRandCoeff(alpha, beta)

		delta_t_expl, triangle_size = problemLOD.initSuperStep(N,nu)
		delta_Ts[i] = np.sum(problemLOD.tau)

	ref = np.divide(np.ones(len(nCoarses)), nCoarses)
	ref_max = np.max(ref)
	delta_Ts_max = np.max(delta_Ts)

	ref = np.divide(ref, ref_max)
	delta_Ts = np.divide(delta_Ts, delta_Ts_max)

	plt.figure(0)
	plt.xscale("log")
	plt.yscale("log")
	plt.xlabel("H")
	plt.ylabel("time")
	plt.plot( ref, delta_Ts, ".-", label="delta_T for N="+str(C)+"*H" )

plt.plot(ref, ref, "k--", label="H")
#plt.plot(ref, np.power(ref,2), "k--", label="H^2")
plt.legend()
plt.show()
