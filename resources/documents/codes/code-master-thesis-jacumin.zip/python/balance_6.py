import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemLOD import DiffusionProblemLOD
from util import norm

u_0 = lambda X: np.zeros(np.prod(X+1))
f = lambda X: np.ones(np.prod(X+1))

# Mesh
nu = 0.00001
alpha = 1
beta  = 1.

nCoarses = np.arange(10, 200, 4)
# problem setting

delta_Ts = np.zeros(len(nCoarses))
for i in range(0, len(nCoarses)):
	nCoarse = nCoarses[i]
	NCoarse = np.array([nCoarse,nCoarse])
	NFine = 2*NCoarse
	
	N = nCoarse

	problemLOD = DiffusionProblemLOD(NFine, NCoarse)
	problemLOD.generateRandCoeff(alpha, beta)

	delta_t_expl, triangle_size = problemLOD.initSuperStep(N,nu)
	delta_Ts[i] = np.sum(problemLOD.tau)

ref = np.divide(np.ones(len(nCoarses)), nCoarses)

plt.figure(0)
plt.xscale("log")
plt.yscale("log")
plt.xlabel("H")
plt.ylabel("time")
plt.plot( ref, delta_Ts, ".-", label="delta_T for N=H" )
plt.plot(ref, ref, "k--", label="H")
plt.legend()
plt.show()
