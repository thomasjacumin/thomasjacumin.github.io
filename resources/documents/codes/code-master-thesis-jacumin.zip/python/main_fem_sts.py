import numpy as np
import matplotlib.pyplot as plt
from util import computeDeltatExpl

from DiffusionProblemFEM import DiffusionProblemFEM

# Mesh
NFine = np.array([100, 100])
N = 10
nu = 0.1
# forcing term
def f(t):
	res = np.zeros(np.prod(NFine+1))
	if t <= 0.002:
		res = np.ones(np.prod(NFine+1))
	return res;
# initial condition
u_0 = lambda X: np.zeros(np.prod(X+1))

# problem setting
alpha = 0.01
beta  = 200.

t_max   = 1.

problemFEM = DiffusionProblemFEM(NFine)
problemFEM.generateRandCoeff(alpha, beta)
problemFEM.assembleMatrices()
problemFEM.f = f(0)

problemFEM.initSuperStep(N,nu)
delta_T = np.sum(problemFEM.tau)

# Initialize the simulation
xFullFEM = u_0(NFine)
# Simulation's loop
nb_loop = int(t_max / delta_T)
for n in range(1, nb_loop):
	t=n*delta_T
	problemFEM.f = f(t)
	xFullFEM = problemFEM.solveSuperStep(xFullFEM, N, nu)

	# plot solution
	plt.figure(0)
	plt.clf()
	plt.imshow(xFullFEM.reshape(NFine+1) )
	plt.title("solution at t=" + str(t*10**6) + "us") 
	plt.colorbar()
	plt.draw()
	plt.pause(0.001)