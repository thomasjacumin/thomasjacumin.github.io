import numpy as np
import matplotlib.pyplot as plt
from scipy import interpolate

from util import norm, computeDeltatExpl

from DiffusionProblemFEM import DiffusionProblemFEM

forcing_term = lambda X: np.ones(np.prod(X+1))

N = 20
nu = 0.01

epsilons = [2**(-2*0), 2**(-2*1), 2**(-2*2), 2**(-2*3), 2**(-2*4), 2**(-2*5)]
for a in range(0, len(epsilons)):
	epsilon = epsilons[a]
	NFine = np.array([2000])

	problemFEM_exact = DiffusionProblemFEM(NFine)
	problemFEM_exact.generatePeriodicCoeff(epsilon)
	problemFEM_exact.assembleMatrices()
	problemFEM_exact.f = forcing_term(NFine)

	beta = np.max(problemFEM_exact.diffusion_coeff)
	delta_t, triangle_size = computeDeltatExpl(NFine, beta)
	delta_t = 0.9*delta_t

	t_max = 100000 * delta_t

	problemFEM_exact.initSuperStep(N,nu)
	delta_T = np.sum(problemFEM_exact.tau)
	xFullFEM_exact = np.zeros(np.prod(NFine+1))
	nb_loop = int(t_max / delta_T)
	for j in range(1, nb_loop):
		print(float(j)/nb_loop)
		xFullFEM_exact = problemFEM_exact.solveSuperStep(xFullFEM_exact, N, nu)

	tests = [2, 10, 20, 50, 100, 500]

	error_L2 = np.zeros(len(tests))
	for i in range(0,len(tests)):
		NCoarse = NFine / tests[i]

		problemFEM = DiffusionProblemFEM(NCoarse)
		problemFEM.generatePeriodicCoeff(epsilon)
		problemFEM.assembleMatrices()
		problemFEM.f = forcing_term(NCoarse)

		problemFEM.tau = problemFEM_exact.tau

		xFullFEM = np.zeros(np.prod(NCoarse+1))
		for j in range(1, nb_loop):
			print(float(j)/nb_loop)
			xFullFEM = problemFEM.solveSuperStep(xFullFEM, N, nu)

		xFullFEM_int = np.interp(np.linspace(0, 1, NFine[0]+1), np.linspace(0, 1, NCoarse[0]+1), xFullFEM)

		error_L2[i] = norm ( xFullFEM_exact - xFullFEM_int, problemFEM_exact.MFull ) / norm ( xFullFEM_exact, problemFEM_exact.MFull )

	error_L2 = np.sqrt(error_L2)

	ref = np.multiply(tests, triangle_size)
	ref_2 = np.power(ref, 2)
	ref_3 = np.sqrt(ref)

	plt.figure(0)
	plt.clf()
	plt.xlabel("h (log)")
	plt.ylabel("Relative error (log)")
	plt.yscale("log")
	plt.xscale("log")
	plt.plot(ref, ref_3, 'k--', label="sqrt(h)")
	plt.plot(ref, ref, 'k--', label="h")
	plt.plot(ref, ref_2, 'k--', label="h^2")
	plt.plot(ref, error_L2, '.-', label="L^2-error")
	plt.legend()
	#plt.show()
	plt.savefig('../generated/fem_x_log_sts_'+str(a+1)+'.png')