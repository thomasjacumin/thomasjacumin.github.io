import numpy as np
import scipy.sparse as sparse
from gridlod import fem, util
from util import computeDeltatExpl

class DiffusionProblemFEM:
	def __init__(self, NPatch):
		self.NPatch = NPatch
		self.diffusion_coeff = np.ones(np.prod(NPatch))
		self.f = np.zeros(np.prod(NPatch+1))

	def generateRandCoeff (self, alpha, beta):
		self.diffusion_coeff = np.random.rand ( np.prod(self.NPatch) )*(beta - alpha) + alpha

	def generateBinaryCoeff (self, alpha, beta):
		self.diffusion_coeff = beta*np.ones ( np.prod(self.NPatch) )
		self.diffusion_coeff[ np.arange(np.prod(self.NPatch)/2) ] = alpha

	def generatePeriodicCoeff(self, epsilon):
		X = np.linspace(0, 1, self.NPatch)
		self.diffusion_coeff = 1./(2+np.cos(2*np.pi*X/epsilon))

	def assembleMatrices(self):
		KLocFull = fem.localStiffnessMatrix(self.NPatch)
		self.KFull = fem.assemblePatchMatrix(self.NPatch, KLocFull, self.diffusion_coeff)
		MLocFull = fem.localMassMatrix(self.NPatch)
		self.MFull = fem.assemblePatchMatrix(self.NPatch, MLocFull)

	def initSuperStep(self, N, nu):
		beta = np.max(self.diffusion_coeff)
		delta_t_expl, triangle_size = computeDeltatExpl(self.NPatch, beta)

		self.tau = np.zeros(N)
		for i in range(1, N+1):
			self.tau[i-1] = delta_t_expl/( (nu-1)*np.cos(np.pi*(2*i-1)/(2*N)) + 1 + nu )

		return delta_t_expl

	def solveStep(self, xFull_previous, delta_t):
		free = util.interiorpIndexMap(self.NPatch)
		
		bFull = delta_t*self.MFull*self.f + (self.MFull - delta_t*self.KFull)*xFull_previous
		
		MFree = self.MFull[free][:,free]
		bFree = bFull[free]
		
		xFree = sparse.linalg.spsolve(MFree, bFree) 
		
		xFull_now = np.zeros(np.prod(self.NPatch+1))
		xFull_now[free] = xFree
		return xFull_now

	def solveSuperStep(self, xFull_previous, N, nu):
		free = util.interiorpIndexMap(self.NPatch)
		MFree = self.MFull[free][:,free]

		for n in range(0, N):
			bFull = self.tau[n]*self.MFull*self.f + (self.MFull - self.tau[n]*self.KFull)*xFull_previous

			bFree = bFull[free]
			xFree_now = sparse.linalg.spsolve(MFree, bFree) 

			xFull_now = np.zeros(np.prod(self.NPatch+1))
			xFull_now[free] = np.transpose(xFree_now)
			xFull_previous = xFull_now

		return xFull_previous