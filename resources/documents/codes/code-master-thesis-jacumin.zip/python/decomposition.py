import numpy as np
import matplotlib.pyplot as plt

xf = np.linspace(-1, 1, 2000)
xc = np.linspace(-1, 1, 10)

fs = 0.01 * np.sin(250*xf)
cs = - xf**2 + 1
ccs = - xc**2 + 1

plt.figure(0)
plt.plot(xc, ccs)
plt.plot(xf, fs)
plt.show()

plt.figure(1)
plt.plot(xf, cs + fs)
plt.show()