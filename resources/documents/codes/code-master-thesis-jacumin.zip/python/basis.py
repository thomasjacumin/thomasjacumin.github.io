import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemFEM import DiffusionProblemFEM
from DiffusionProblemLOD import DiffusionProblemLOD

NFine = np.array([500])
NCoarse = np.array([10])

problemLOD = DiffusionProblemLOD(NFine, NCoarse)
problemLOD.diffusion_coeff = 5 * (np.cos( 2*np.pi*200 * np.linspace(0,1,NFine[0]) ) + 1) + 1
#problemLOD.diffusion_coeff = np.ones(np.prod(NFine))
lod_basis, fem_basis = problemLOD.assembleMatrices()

#plt.figure(0)
#plt.plot(fem_basis.toarray()[:,4])
#plt.plot(fem_basis.toarray()[:,5])
#plt.plot(fem_basis.toarray()[:,6])
#plt.show()

plt.figure(1)
#plt.plot(lod_basis.toarray()[:,4])
plt.plot(lod_basis.toarray()[:,5])
#plt.plot(lod_basis.toarray()[:,6])
plt.show()

plt.figure(0)
#plt.plot(fem_basis.toarray()[:,4])
plt.plot(fem_basis.toarray()[:,5] - lod_basis.toarray()[:,5])
#plt.plot(fem_basis.toarray()[:,6])
plt.show()