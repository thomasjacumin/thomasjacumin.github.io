import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemLOD import DiffusionProblemLOD
from util import norm

u_0 = lambda X: np.zeros(np.prod(X+1))
f = lambda X: np.ones(np.prod(X+1))

# Mesh
nu = 0.1
nCoarses = range(100, 200)
# problem setting
alpha = 1
beta  = 1.

delta_Ts_1 = np.zeros(len(nCoarses))
delta_Ts_2 = np.zeros(len(nCoarses))
delta_Ts_3 = np.zeros(len(nCoarses))
for i in range(0, len(nCoarses)):
	nCoarse = nCoarses[i]
	NCoarse = np.array([nCoarse,nCoarse])
	NFine = 2*NCoarse
	
	N_1 = int(0.01*nCoarse)
	N_2 = nCoarse
	N_3 = 4*nCoarse

	problemLOD = DiffusionProblemLOD(NFine, NCoarse)
	problemLOD.generateRandCoeff(alpha, beta)

	delta_t_expl, triangle_size = problemLOD.initSuperStep(N_1,nu)
	delta_Ts_1[i] = np.sum(problemLOD.tau)
	delta_t_expl, triangle_size = problemLOD.initSuperStep(N_2,nu)
	delta_Ts_2[i] = np.sum(problemLOD.tau)
	delta_t_expl, triangle_size = problemLOD.initSuperStep(N_3,nu)
	delta_Ts_3[i] = np.sum(problemLOD.tau)

ref = np.divide(np.ones(len(nCoarses)), nCoarses)

plt.figure(0)
plt.xscale("log")
plt.yscale("log")
plt.xlabel("H")
plt.ylabel("time")
plt.plot( ref, delta_Ts_1, ".-", label="delta_T for N=0.01*H" )
plt.plot( ref, delta_Ts_2, ".-", label="delta_T for N=H" )
plt.plot( ref, delta_Ts_3, ".-", label="delta_T for N=4*H" )
plt.plot(ref, ref, "k--", label="H")
plt.plot(ref, 0.1*np.power(ref,2), "k--", label="H^2")
plt.legend()
plt.show()
