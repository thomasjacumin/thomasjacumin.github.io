import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemFEM import DiffusionProblemFEM
from DiffusionProblemLOD import DiffusionProblemLOD

NFine = np.array([500])
NCoarse = np.array([10])

xf = np.linspace(0,1,NFine[0]+1)
xc = np.linspace(0,1,NCoarse[0]+1)

problemLOD = DiffusionProblemLOD(NFine, NCoarse)
problemLOD.diffusion_coeff = 50 * (np.cos( 246 * np.linspace(0,1,NFine[0]) + 20 ) + 1) + 1
lod_basis, fem_basis = problemLOD.assembleMatrices()

f = -xc**2 + xc

plt.figure(0)
plt.plot(xf, lod_basis*f)
plt.plot(xc, f)
plt.show()