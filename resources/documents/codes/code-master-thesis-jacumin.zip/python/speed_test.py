import numpy as np
import matplotlib.pyplot as plt
import time
from scipy import interpolate

from util import norm, computeDeltatExpl

from DiffusionProblemLOD import DiffusionProblemLOD
from DiffusionProblemFEM import DiffusionProblemFEM

enable_fem_euler = 0
enable_fem_sts   = 0
enable_lod_euler = 0
enable_lod_sts   = 1

forcing_term = lambda X: np.ones(np.prod(X+1))
u_0          = lambda X: np.zeros(np.prod(X+1))
beta = 1
epsilon = 2**(-2*2)

t_max = 0.001
FEM_NFine   = [100, 200, 500, 1000, 1500]
LOD_NCoarse = [50, 100, 200, 500, 1000]
Ns = [1, 2, 5, 10, 20]
nus = [1, 0.1, 0.01]

# exact solution
print("Computing exact solution...")
last_time = time.time()
NFine_exact = np.array([2000])

problemFEM_exact = DiffusionProblemFEM(NFine_exact)
problemFEM_exact.generatePeriodicCoeff(epsilon)

problemFEM_exact.assembleMatrices()
ma_time = time.time() - last_time
last_time = time.time()

problemFEM_exact.f = forcing_term(NFine_exact)

delta_t_expl, triangle_size = computeDeltatExpl(NFine_exact, beta)
delta_t = delta_t_expl

xFullFEM_exact = u_0(NFine_exact)
nb_loop = int(t_max / delta_t)
for j in range(1, nb_loop):
	print(float(j)/nb_loop)
	xFullFEM_exact = problemFEM_exact.solveStep(xFullFEM_exact, delta_t)
tot_time = time.time() - last_time
print("Done in %s seconds" % (tot_time))

if ( enable_fem_euler ):
	# fem/euler solution
	file = open("../generated/speed_results_fem_euler.csv", "w")
	file.write("vbeta,nfine,ncoarse,dtexpl,vn,vnu,tmax,matime,tottime,error\n")
	for nFine in FEM_NFine:
		NFine = np.array([nFine])

		print("\n")
		print("NFine = "+str(NFine))
		print("Computing fem/euler solution... in 3 seconds")
		time.sleep(3)
		last_time = time.time()

		problemFEM = DiffusionProblemFEM(NFine)
		problemFEM.generatePeriodicCoeff(epsilon)
		problemFEM.f = forcing_term(NFine)

		problemFEM.assembleMatrices()
		ma_time = time.time() - last_time
		last_time = time.time()

		delta_t_expl, triangle_size = computeDeltatExpl(NFine, beta)
		delta_t = delta_t_expl

		xFullFEM = u_0(NFine)
		nb_loop = int(t_max / delta_t)
		for j in range(1, nb_loop):
			print(float(j)/nb_loop)
			xFullFEM = problemFEM.solveStep(xFullFEM, delta_t)
		tot_time = time.time() - last_time
		print("Done in %s seconds" % (time.time() - last_time))
		xFullFEM_int = np.interp(np.linspace(0, 1, NFine_exact[0]+1), np.linspace(0, 1, NFine[0]+1), xFullFEM)
		error_L2 = norm ( xFullFEM_exact - xFullFEM_int, problemFEM_exact.MFull )
		print("Error=%s" % error_L2 )

		file.write("%d,%d,-,%.1f,-,-,%.1f,%.1f,%.1f,%.3e\n" % (beta,NFine[0],delta_t*1e9,1000*t_max,1000*ma_time,1000*tot_time,error_L2))

	file.close()

if (enable_fem_sts):
	# fem/STS solution
	file = open("../generated/speed_results_fem_sts.csv", "w")
	file.write("vbeta,nfine,ncoarse,dtexpl,vn,vnu,tmax,matime,tottime,error\n")
	for N in Ns:
		for nu in nus:
			NFine = np.array([2000])
			print("\n")
			print("NFine = "+str(NFine))
			print("N = "+str(N))
			print("nu = "+str(nu))
			print("Computing fem/sts solution... in 3 seconds")
			time.sleep(3)

			last_time = time.time()
			problemFEM = DiffusionProblemFEM(NFine)
			problemFEM.generatePeriodicCoeff(epsilon)
			problemFEM.f = forcing_term(NFine)

			problemFEM.assembleMatrices()
			ma_time = time.time() - last_time
			last_time = time.time()

			delta_t = problemFEM.initSuperStep(N, nu)
			delta_T = np.sum(problemFEM.tau)

			xFullFEM = u_0(NFine)
			nb_loop = int(t_max / delta_T)
			for j in range(1, nb_loop):
				print(float(j)/nb_loop)
				xFullFEM = problemFEM.solveSuperStep(xFullFEM, N, nu)
			tot_time = time.time() - last_time
			print("Done in %s seconds" % (time.time() - last_time))
			xFullFEM_int = np.interp(np.linspace(0, 1, NFine_exact[0]+1), np.linspace(0, 1, NFine[0]+1), xFullFEM)
			error_L2 = norm ( xFullFEM_exact - xFullFEM_int, problemFEM_exact.MFull )
			print("Error=%s" % error_L2 )
			file.write("%d,%d,-,%.1f,%d,%.2f,%.1f,%.1f,%.1f,%.3e\n" % (beta,NFine[0],delta_t*1e9,N,nu,1000*t_max,1000*ma_time,1000*tot_time,error_L2))
	file.close()

if ( enable_lod_euler ):
	# lod/euler solution
	file = open("../generated/speed_results_lod_euler.csv", "w")
	file.write("vbeta,nfine,ncoarse,dtexpl,vn,vnu,tmax,matime,tottime,error\n")
	for nCoarse in LOD_NCoarse:
		NFine = np.array([2000])
		NCoarse = np.array([nCoarse])

		print("\n")
		print("NFine = "+str(NFine))
		print("NCoarse = "+str(NCoarse))
		print("Computing lod/euler solution... in 3 seconds")
		time.sleep(3)
		last_time = time.time()

		problemLOD = DiffusionProblemLOD(NFine, NCoarse)
		problemLOD.generatePeriodicCoeff(epsilon)
		problemLOD.f = forcing_term(NCoarse)

		lod_basis, fem_basis = problemLOD.assembleMatrices()
		ma_time = time.time() - last_time
		last_time = time.time()

		delta_t_expl, triangle_size = computeDeltatExpl(NCoarse, beta)
		delta_t = delta_t_expl

		xFullLOD = u_0(NCoarse)
		nb_loop = int(t_max / delta_t)
		for j in range(1, nb_loop):
			print(float(j)/nb_loop)
			xFullLOD = problemLOD.solveStep(xFullLOD, delta_t)
		tot_time = time.time() - last_time
		print("Done in %s seconds" % (time.time() - last_time))
		xFullLOD_int = lod_basis*xFullLOD
		error_L2 = norm ( xFullFEM_exact - xFullLOD_int, problemFEM_exact.MFull )
		print("Error=%s" % error_L2 )
		file.write("%d,%d,%d,%.1f,-,-,%.1f,%.1f,%.1f,%.3e\n" % (beta,NFine[0],NCoarse[0],delta_t*1e9,1000*t_max,1000*ma_time,1000*tot_time,error_L2))
	file.close()

if ( enable_lod_sts ):
	# lod/STS solution
	file = open("../generated/speed_results_lod_sts.csv", "w")
	file.write("vbeta,nfine,ncoarse,dtexpl,vn,vnu,tmax,matime,tottime,error\n")
	for nCoarse in LOD_NCoarse:
		for N in Ns:
			for nu in nus:
				NFine = np.array([2000])
				NCoarse = np.array([nCoarse])

				print("\n")
				print("NFine = "+str(NFine))
				print("NCoarse = "+str(NCoarse))
				print("N = "+str(N))
				print("nu = "+str(nu))
				print("Computing lod/sts solution... in 3 seconds")
				time.sleep(3)

				last_time = time.time()

				problemLOD = DiffusionProblemLOD(NFine, NCoarse)
				problemLOD.generatePeriodicCoeff(epsilon)
				problemLOD.f = forcing_term(NCoarse)

				lod_basis, fem_basis = problemLOD.assembleMatrices()
				ma_time = time.time() - last_time
				last_time = time.time()

				delta_t = problemLOD.initSuperStep(N, nu)
				delta_T = np.sum(problemLOD.tau)

				xFullLOD = u_0(NCoarse)
				nb_loop = int(t_max / delta_T)
				for j in range(1, nb_loop):
					print(float(j)/nb_loop)
					xFullLOD = problemLOD.solveSuperStep(xFullLOD, N, nu)
				tot_time = time.time() - last_time
				print("Done in %s seconds" % (time.time() - last_time))
				xFullLOD_int = lod_basis*xFullLOD
				error_L2 = norm ( xFullFEM_exact - xFullLOD_int, problemFEM_exact.MFull )
				print("Error=%s" % error_L2 )
				file.write("%d,%d,%d,%.1f,%d,%.2f,%.1f,%.1f,%.1f,%.3e\n" % (beta,NFine[0],NCoarse[0],delta_t*1e9,N,nu,1000*t_max,1000*ma_time,1000*tot_time,error_L2))
	file.close()
