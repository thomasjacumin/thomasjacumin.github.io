Copyright 2017 Fredrik Hellman (fredrik.hellman@gmail.com)
