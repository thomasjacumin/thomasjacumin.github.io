import numpy as np

def norm(u, A):
	res = np.transpose(u)
	res = res*A
	res = np.dot(res, u)
	return res

def computeDeltatExpl(NFine, beta ):
	if ( len(NFine) == 1):
		triangle_size = 1./NFine[0]
	elif ( len(NFine) == 2):
		triangle_size = 1./(np.maximum(NFine[0], NFine[1]))
	return 0.089/beta*triangle_size**2, triangle_size