import numpy as np
import matplotlib.pyplot as plt
from scipy import interpolate

from util import norm, computeDeltatExpl

from DiffusionProblemLOD import DiffusionProblemLOD
from DiffusionProblemFEM import DiffusionProblemFEM

forcing_term = lambda X: np.ones(np.prod(X+1))

N = 20
nu = 0.01

epsilons = [2**(-2*0), 2**(-2*1), 2**(-2*2), 2**(-2*3), 2**(-2*4), 2**(-2*5)]
for a in range(0, len(epsilons)):
	epsilon = epsilons[a]
	NFine = np.array([2000])

	problemFEM_exact = DiffusionProblemFEM(NFine)
	problemFEM_exact.generatePeriodicCoeff(epsilon)
	problemFEM_exact.assembleMatrices()
	problemFEM_exact.f = forcing_term(NFine)

	beta = np.max(problemFEM_exact.diffusion_coeff)
	delta_t, triangle_size = computeDeltatExpl(NFine, beta)
	delta_t = 0.9*delta_t

	t_max = 100000 * delta_t

	problemFEM_exact.initSuperStep(N,nu)
	delta_T = np.sum(problemFEM_exact.tau)
	xFullFEM_exact = np.zeros(np.prod(NFine+1))
	nb_loop = int(t_max / delta_T)
	for j in range(1, nb_loop):
		print(float(j)/nb_loop)
		xFullFEM_exact = problemFEM_exact.solveSuperStep(xFullFEM_exact, N, nu)

	tests = [500, 200, 100, 50, 25, 10, 5]

	error_L2 = np.zeros(len(tests))
	loc_error_L2 = np.zeros(len(tests))
	opti_loc_error_L2 = np.zeros(len(tests))
	for i in range(0,len(tests)):
		NCoarse = np.array([tests[i]])

		# non-localized pb
		problemLOD = DiffusionProblemLOD(NFine, NCoarse)
		problemLOD.generatePeriodicCoeff(epsilon)
		lod_basis, fem_basis = problemLOD.assembleMatrices(k=300)
		problemLOD.f = forcing_term(NCoarse)
		problemLOD.tau = problemFEM_exact.tau

		# localized pb
		loc_problemLOD = DiffusionProblemLOD(NFine, NCoarse)
		loc_problemLOD.generatePeriodicCoeff(epsilon)
		loc_lod_basis, loc_fem_basis = loc_problemLOD.assembleMatrices(k=0)
		loc_problemLOD.f = forcing_term(NCoarse)
		loc_problemLOD.tau = problemFEM_exact.tau

		opti_loc_problemLOD = DiffusionProblemLOD(NFine, NCoarse)
		opti_loc_problemLOD.generatePeriodicCoeff(epsilon)
		opti_loc_lod_basis, opti_loc_fem_basis = opti_loc_problemLOD.assembleMatrices(k=int(np.log(NCoarse[0])))
		opti_loc_problemLOD.f = forcing_term(NCoarse)
		opti_loc_problemLOD.tau = problemFEM_exact.tau

		loc_xFullLOD = np.zeros(np.prod(NCoarse+1))
		opti_loc_xFullLOD = np.zeros(np.prod(NCoarse+1))
		xFullLOD = np.zeros(np.prod(NCoarse+1))
		for j in range(1, nb_loop):
			print(float(j)/nb_loop)
			xFullLOD = problemLOD.solveSuperStep(xFullLOD, N, nu)
			loc_xFullLOD = loc_problemLOD.solveSuperStep(loc_xFullLOD, N, nu)
			opti_loc_xFullLOD = opti_loc_problemLOD.solveSuperStep(opti_loc_xFullLOD, N, nu)

		error_L2[i] = norm ( xFullFEM_exact - lod_basis*xFullLOD, problemFEM_exact.MFull ) / norm ( xFullFEM_exact, problemFEM_exact.MFull )
		loc_error_L2[i] = norm ( xFullFEM_exact - loc_lod_basis*loc_xFullLOD, problemFEM_exact.MFull ) / norm ( xFullFEM_exact, problemFEM_exact.MFull )
		opti_loc_error_L2[i] = norm ( xFullFEM_exact - opti_loc_lod_basis*opti_loc_xFullLOD, problemFEM_exact.MFull ) / norm ( xFullFEM_exact, problemFEM_exact.MFull )

	error_L2 = np.sqrt(error_L2)
	loc_error_L2 = np.sqrt(loc_error_L2)
	opti_loc_error_L2 = np.sqrt(opti_loc_error_L2)

	ref = np.divide(np.ones(len(tests)), tests)
	ref_2 = np.power(ref, 2)
	ref_3 = np.sqrt(ref)

	plt.figure(0)
	plt.clf()
	plt.xlabel("H (log)")
	plt.ylabel("Relative error (log)")
	plt.yscale("log")
	plt.xscale("log")
	plt.plot(ref, ref_3, 'k--', label="sqrt(H)")
	plt.plot(ref, ref, 'k--', label="H")
	plt.plot(ref, ref_2, 'k--', label="H^2")
	plt.plot(ref, error_L2, 'o-', label="L^2-error for unlocalized method")
	plt.plot(ref, loc_error_L2, 'x-', label="L^2-error for localized method k=0")
	plt.plot(ref, opti_loc_error_L2, '.-', label="L^2-error for localized method k=log(H)")
	plt.legend()
	#plt.show()
	plt.savefig('../generated/lod_x_log_sts_'+str(a+1)+'.png')