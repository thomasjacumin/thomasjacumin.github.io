import numpy as np
import matplotlib.pyplot as plt

from util import norm, computeDeltatExpl

from DiffusionProblemFEM import DiffusionProblemFEM

#test = np.arange(5, 100, 5)
test = [2, 4, 8, 16, 32, 64, 128, 256]
test_max = np.max(test)

NFine = np.array([300])
epsilon = 2**(-2*2)

beta  = 1
delta_t_expl, triangle_size = computeDeltatExpl(NFine, beta)
delta_t_expl = 0.5*delta_t_expl
delta_t = delta_t_expl / test_max
t_max = 100 * delta_t * test_max

problemFEM = DiffusionProblemFEM(NFine)
problemFEM.generatePeriodicCoeff(epsilon)
problemFEM.f = np.ones(np.prod(NFine+1))

problemFEM.assembleMatrices()

# Simulation's loop
xFullFEM = np.zeros(np.prod(NFine+1))
nb_loop = int(t_max/delta_t)
for n in range(1, nb_loop ):
	print(float(n)/nb_loop)
	xFullFEM = problemFEM.solveStep(xFullFEM, delta_t)

error = np.zeros(len(test))
for i in range(0, len(test)):
	k = test[i]
	xFullFEM_test = np.zeros(np.prod(NFine+1))
	nb_loop = int(t_max/(delta_t*k))
	for n in range(1, nb_loop):
		print(float(n)/nb_loop)
		xFullFEM_test = problemFEM.solveStep(xFullFEM_test, delta_t*k)

	error[i] = norm(xFullFEM - xFullFEM_test, problemFEM.MFull) / norm(xFullFEM, problemFEM.MFull)


error = np.sqrt(error)

ref = np.multiply( test, delta_t )
ref_2 = np.power(ref, 2)
ref_3 = np.sqrt(ref)

plt.figure(0)
plt.xlabel("delta_t (log)")
plt.ylabel("Reltive error (log)")
plt.yscale("log")
plt.xscale("log")
plt.plot(ref, ref_3, 'k--', label="sqrt(delta_t)")
plt.plot(ref, ref, 'k--', label="delta_t")
plt.plot(ref, ref_2, 'k--', label="delta_t^2")
plt.plot(ref, error, '.-', label="L^2-error")
plt.legend()
plt.savefig('../generated/fem_t_log.png')