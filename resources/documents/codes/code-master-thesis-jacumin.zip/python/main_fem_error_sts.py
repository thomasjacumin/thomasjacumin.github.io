import numpy as np
import matplotlib.pyplot as plt

from util import norm, computeDeltatExpl

from DiffusionProblemFEM import DiffusionProblemFEM

NTest = [20]
#NTest = [5, 10, 20, 30]
nus = np.logspace(0.001, 2, 10)
N_max = np.max(NTest)
nu_min = np.min(nus)

NFine = np.array([300])

problemFEM = DiffusionProblemFEM(NFine)
problemFEM.generatePeriodicCoeff(2**(-2*1))
problemFEM.f = np.ones(np.prod(NFine+1))
problemFEM.assembleMatrices()

delta_t_expl = problemFEM.initSuperStep(N_max, nu_min)
delta_T = np.sum(problemFEM.tau)
t_max = 100 * delta_T

delta_t_expl = 0.9*delta_t_expl

# Simulation's loop
xFullFEM = np.zeros(np.prod(NFine+1))
nb_loop = int(t_max/delta_t_expl)
for n in range(1, nb_loop ):
	print(float(n)/nb_loop)
	xFullFEM = problemFEM.solveStep(xFullFEM, delta_t_expl)

delta_T = np.zeros(len(nus)*len(NTest))
error = np.zeros(len(nus)*len(NTest))
for j in range(0, len(NTest)):
	for i in range(0, len(nus)):
		N = NTest[j]
		nu = nus[i]
		xFullFEM_test = np.zeros(np.prod(NFine+1))
		problemFEM.initSuperStep(N, nu)
		delta_T[i] = np.sum(problemFEM.tau)
		nb_loop = int(t_max/delta_T[i])
		for n in range(1, nb_loop):
			print(float(n)/nb_loop)
			xFullFEM_test = problemFEM.solveSuperStep(xFullFEM_test, N, nu)

		error[j+i] = norm(xFullFEM - xFullFEM_test, problemFEM.MFull) / norm(xFullFEM, problemFEM.MFull)

error = np.sqrt(error)

ref = delta_T
ref_2 = np.power(ref, 2)
ref_3 = np.sqrt(ref)

#ref = np.multiply(ref, np.min(error)/np.min(ref))

plt.figure(0)
plt.xlabel("delta_T (log)")
plt.ylabel("Relative error (log)")
plt.yscale("log")
plt.xscale("log")
plt.plot(ref, ref_3, 'k--', label="sqrt(delta_T)")
plt.plot(ref, ref, 'k--', label="delta_T")
#plt.plot(ref, ref_2, 'k--', label="delta_T^2")
plt.plot(ref, error, '.-', label="L^2-error")
plt.legend()
plt.savefig('../generated/fem_sts_log.png')