import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemLOD import DiffusionProblemLOD
from util import norm

# Mesh
NFine = np.array([128, 128])
NCoarse = np.array([32,32])
N = 10
nu = 0.01
# forcing term
def f(t):
	res = np.zeros(np.prod(NCoarse+1))
	if t >= 0.0000002:
		res = 1000*np.ones(np.prod(NCoarse+1))
	return res;
# initial condition
u_0 = lambda X: np.ones(np.prod(X+1))

# problem setting
alpha = 0.01
beta  = 200.

t_max   = 1.

problemLOD = DiffusionProblemLOD(NFine, NCoarse)
problemLOD.generateRandCoeff(alpha, beta)
lod_basis, fem_basis = problemLOD.assembleMatrices()
problemLOD.f = f(0)

problemLOD.initSuperStep(N,nu)
delta_T = np.sum(problemLOD.tau)

# Initialize the simulation
xFullLOD = u_0(NCoarse)
# Simulation's loop
nb_loop = int(t_max / delta_T)
for n in range(1, nb_loop):
	t=n*delta_T
	problemLOD.f = f(t)
	xFullLOD = problemLOD.solveSuperStep(xFullLOD, N, nu)

	# plot solution
	plt.figure(0)
	plt.clf()
	plt.imshow((lod_basis*xFullLOD).reshape(NFine+1), vmin = 0, vmax = 1 )
	plt.title("solution at t=" + str(t*10**6) + "us") 
	plt.colorbar()
	plt.draw()
	plt.pause(0.001)