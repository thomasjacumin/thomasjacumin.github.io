import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.axes3d import Axes3D

f = lambda N,nu: N/2./np.sqrt(nu)*((1+np.sqrt(nu))**(2*N)-(1-np.sqrt(nu))**(2*N))/((1+np.sqrt(nu))**(2*N)+(1-np.sqrt(nu))**(2*N))
tau = lambda N, nu, i: 1./( (nu-1)*np.cos(np.pi*(2*i-1)/(2*N)) + 1 + nu )

N = np.arange(1,100,1.)
nu = np.linspace(0.0001, 0.1, 100)

xx, yy = np.meshgrid(N, nu)
z = f(xx,yy)

plt.figure(0)
plt.plot(N, f(N,0.1))
plt.show()

# fig = plt.figure(0)
# ax = fig.add_subplot(1, 1, 1, projection='3d')
# p = ax.plot_wireframe(xx, yy, z, rstride=4, cstride=4)
# plt.show()