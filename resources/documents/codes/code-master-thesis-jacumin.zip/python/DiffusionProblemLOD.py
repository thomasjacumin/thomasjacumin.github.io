import numpy as np
import scipy.sparse as sparse
from gridlod import pg, interp, coef, util, fem, world, linalg, femsolver, transport
from gridlod.world import World

from util import computeDeltatExpl

class DiffusionProblemLOD:
	def __init__(self, NFine, NCoarse):
		mod = NFine % NCoarse
		if ( len(NFine) == 1 ):
			assert ( mod[0] == 0 ), "NCoarse is not a refinement of NFine"
		elif ( len(NFine) == 2 ):
			assert ( mod[0] == 0 and mod[1] == 0 ), "NCoarse is not a refinement of NFine"
		else:
			assert ( true == false ), "Dimension not supported"

		self.NFine = NFine
		self.NCoarse = NCoarse
		self.diffusion_coeff = np.ones(np.prod(NFine))
		self.f = np.zeros(np.prod(NCoarse+1))
		NCoarseElement = self.NFine/self.NCoarse

		if ( len(NFine) == 1 ):
			self.boundaryConditions = np.array([[0, 0]])
		elif ( len(NFine) == 2 ):
			self.boundaryConditions = np.array([[0, 0], [0, 0]])
			self.P = interp.L2ProjectionPatchMatrix(np.array([0,0]), self.NCoarse, self.NCoarse, NCoarseElement, self.boundaryConditions)

	def generateRandCoeff (self, alpha, beta):
		self.diffusion_coeff = np.random.rand ( np.prod(self.NFine) )*(beta - alpha) + alpha

	def generateBinaryCoeff (self, alpha, beta):
		self.diffusion_coeff = beta*np.ones ( np.prod(self.NFine) )
		self.diffusion_coeff[ np.arange(np.prod(self.NFine)/2) ] = alpha

	def generatePeriodicCoeff(self, epsilon):
		X = np.linspace(0, 1, self.NFine)
		self.diffusion_coeff = 1./(2+np.cos(2*np.pi*X/epsilon))

	def initSuperStep(self, N, nu):
		beta = np.max(self.diffusion_coeff)
		delta_t_expl, triangle_size = computeDeltatExpl(self.NCoarse, beta)

		self.tau = np.zeros(N)
		for i in range(1, N+1):
			self.tau[i-1] = delta_t_expl/( (nu-1)*np.cos(np.pi*(2*i-1)/(2*N)) + 1 + nu )

		return delta_t_expl, triangle_size

	def assembleMatrices(self, k=2):
		NCoarseElement = self.NFine/self.NCoarse
		world = World(self.NCoarse, NCoarseElement, self.boundaryConditions)

		rCoarse = np.ones(np.prod(self.NCoarse))
		aCoef = coef.coefficientCoarseFactor(self.NCoarse, NCoarseElement, self.diffusion_coeff, rCoarse)

		IPatchGenerator = lambda i, N: interp.L2ProjectionPatchMatrix(i, N, self.NCoarse, NCoarseElement, self.boundaryConditions)
		pglod = pg.PetrovGalerkinLOD(world, k, IPatchGenerator, 0)
		pglod.updateCorrectors(aCoef, clearFineQuantities=False)

		self.KFull = pglod.assembleMsStiffnessMatrix() # Striffness Matrix
		self.MFull = fem.assemblePatchMatrix(self.NCoarse, world.MLocCoarse) # Mass Matrix

		basis = fem.assembleProlongationMatrix(self.NCoarse, NCoarseElement) # VH basis
		basisCorrectors = pglod.assembleBasisCorrectors() # WH basis
		modifiedBasis = basis - basisCorrectors # ~VH basis

		return modifiedBasis, basis

	def solveStep(self, xFull_previous, delta_t):
		NCoarseElement = self.NFine/self.NCoarse
		free = util.interiorpIndexMap(self.NCoarse)

		bFull = delta_t*self.MFull*self.f + (self.MFull - delta_t*self.KFull)*xFull_previous

		MFree = self.MFull[free][:,free]
		bFree = bFull[free]

		xFree = sparse.linalg.spsolve(MFree, bFree) 

		xFull_now = np.zeros(np.prod(self.NCoarse+1))
		xFull_now[free] = xFree
		return xFull_now

	def solveSuperStep(self, xFull_previous, N, nu):
		beta = np.max(self.diffusion_coeff)
		delta_t_expl = computeDeltatExpl(self.NCoarse, beta)

		free = util.interiorpIndexMap(self.NCoarse)
		MFree = self.MFull[free][:,free]

		for n in range(0, N):
			bFull = self.tau[n]*self.MFull*self.f + (self.MFull - self.tau[n]*self.KFull)*xFull_previous

			bFree = bFull[free]
			xFree_now = sparse.linalg.spsolve(MFree, bFree) 

			xFull_now = np.zeros(np.prod(self.NCoarse+1))
			xFull_now[free] = np.transpose(xFree_now)
			xFull_previous = xFull_now

		return xFull_previous