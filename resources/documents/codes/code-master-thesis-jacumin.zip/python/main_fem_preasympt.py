import numpy as np
import matplotlib.pyplot as plt

from util import norm

from DiffusionProblemFEM import DiffusionProblemFEM

def DiffCoeff( X, epsilon, NFine ):
	return np.cos( epsilon * X / NFine[0] )+1.01

NFine = np.array([600])
ns = [2, 4, 8]
for n in ns:
	N = 20
	nu = 0.01

	epsilon = 290
	A_exact = DiffCoeff ( np.arange(0, NFine, 1.), epsilon, NFine )
	A = DiffCoeff ( np.arange(0, NFine, float(n)), epsilon, NFine )

	beta  = np.max(A_exact)
	triangle_size = 1./NFine[0]
	delta_t_expl = 0.089/beta*triangle_size**2
	delta_t = delta_t_expl

	problemFEM_exact = DiffusionProblemFEM(NFine)
	problemFEM = DiffusionProblemFEM(NFine / n)

	problemFEM_exact.diffusion_coeff = A_exact
	problemFEM.diffusion_coeff = A

	problemFEM_exact.f = np.ones(np.prod(NFine+1))
	problemFEM.f = np.ones(np.prod(NFine/n+1))
		
	problemFEM_exact.assembleMatrices()
	problemFEM.assembleMatrices()

	tau = np.zeros(N)
	for i in range(1, N+1):
		tau[i-1] = delta_t_expl/( (nu-1)*np.cos(np.pi*(2*i-1)/(2*N)) + 1 + nu )
	problemFEM_exact.tau = tau
	problemFEM.tau = tau
	delta_T = np.sum(tau)

	# Simulation's loop
	xFullFEM_exact = np.zeros(np.prod(NFine+1))
	xFullFEM = np.zeros(np.prod(NFine/n+1))
	plt.figure(0)

	t_max = 0.1
	nb_loop = int(t_max/delta_T)
	for i in range (1, nb_loop):
		print(float(i)/nb_loop)
		xFullFEM_exact = problemFEM_exact.solveSuperStep(xFullFEM_exact, N, nu)
		xFullFEM = problemFEM.solveSuperStep(xFullFEM, N, nu)

	plt.clf()
	plt.title("t = {:.3f} s".format(i*delta_T))
	plt.plot(range(0, NFine+1), xFullFEM_exact, label="exact")
	plt.plot(range(0, NFine+1, n), xFullFEM, label="FEM solution for NFine="+str(NFine/n))
	plt.legend()
	plt.savefig('../generated/fem_preasympt_'+str(NFine[0]/n)+'.png')