import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemFEM import DiffusionProblemFEM

NFine = np.array([20, 20])
nu = 0.000001
Ns = [ 5, 10, 15, 20, 25 ]
Nmax = np.max(Ns)

problemFEM = DiffusionProblemFEM(NFine)
delta_t_expl = 0

plt.figure(0)
plt.title("Super-step when nu tends to 0")
plt.xlabel("n (log)")
plt.ylabel("t (log)")

for N in Ns:
	delta_t_expl = problemFEM.initSuperStep(N, nu)
	super_step = np.zeros(N)
	super_step[0] = problemFEM.tau[0]
	for i in range(1,N):
		super_step[i] = super_step[i-1]+problemFEM.tau[i]

	plt.plot(range(1,N+1), super_step, '.-', label="N="+str(N))

plt.plot(range(1,Nmax+1), [delta_t_expl*x*x for x in range(1,Nmax+1)], 'k--', label="delta_t_expl*N^2")
plt.xscale("log")
plt.yscale("log")
plt.legend()
#plt.show()
plt.savefig("../generated/sts_tau_lim.png")