import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemLOD import DiffusionProblemLOD
from util import norm

u_0 = lambda X: np.zeros(np.prod(X+1))
f = lambda X: np.ones(np.prod(X+1))

# Mesh
nus = np.linspace(0.0001, 1, 5)

for nu in nus:
	nCoarses = range(100, 200)
	# problem setting
	alpha = 1
	beta  = 1.

	delta_Ts = np.zeros(len(nCoarses))
	for i in range(0, len(nCoarses)):
		nCoarse = nCoarses[i]
		NCoarse = np.array([nCoarse,nCoarse])
		NFine = 2*NCoarse
		
		N = nCoarse

		problemLOD = DiffusionProblemLOD(NFine, NCoarse)
		problemLOD.generateRandCoeff(alpha, beta)

		delta_t_expl, triangle_size = problemLOD.initSuperStep(N,nu)
		delta_Ts[i] = np.sum(problemLOD.tau)

	ref = np.divide(np.ones(len(nCoarses)), nCoarses)

	plt.figure(0)
	plt.plot( ref, delta_Ts, ".-", label="delta_T for nu={:.4f}".format(nu) )

plt.figure(0)
plt.xscale("log")
plt.yscale("log")
plt.xlabel("H")
plt.ylabel("time")
plt.plot(ref, ref, "k--", label="H")
plt.legend()
plt.show()
