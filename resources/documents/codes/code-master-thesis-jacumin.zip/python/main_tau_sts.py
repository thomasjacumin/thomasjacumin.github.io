import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemFEM import DiffusionProblemFEM

NFine = np.array([20, 20])
N  = 10
 
problemFEM = DiffusionProblemFEM(NFine)
delta_t_expl = problemFEM.initSuperStep(N, 0.1)
normal_step = N*delta_t_expl * np.ones(N)

super_step_1 = np.zeros(len(problemFEM.tau))
super_step_1[0] = problemFEM.tau[0]
for i in range(1,len(problemFEM.tau)):
	super_step_1[i] = super_step_1[i-1]+problemFEM.tau[i]

delta_t_expl = problemFEM.initSuperStep(N, 0.01)

super_step_2 = np.zeros(len(problemFEM.tau))
super_step_2[0] = problemFEM.tau[0]
for i in range(1,len(problemFEM.tau)):
	super_step_2[i] = super_step_2[i-1]+problemFEM.tau[i]

delta_t_expl = problemFEM.initSuperStep(N, 1)

super_step_3 = np.zeros(len(problemFEM.tau))
super_step_3[0] = problemFEM.tau[0]
for i in range(1,len(problemFEM.tau)):
	super_step_3[i] = super_step_3[i-1]+problemFEM.tau[i]

delta_t_expl = problemFEM.initSuperStep(N, 0.000001)

super_step_4 = np.zeros(len(problemFEM.tau))
super_step_4[0] = problemFEM.tau[0]
for i in range(1,len(problemFEM.tau)):
	super_step_4[i] = super_step_4[i-1]+problemFEM.tau[i]

plt.figure(1)
plt.xscale("log")
plt.yscale("log")
plt.title("Influence of nu on the super-step for N="+str(N))
plt.xlabel("n (log)")
plt.ylabel("t (log)")
plt.plot(range(1,N+1), normal_step, 'kx--', label="delta_t_expl")
plt.plot(range(1,N+1), super_step_1, 'r.-', label="nu=0.1")
plt.plot(range(1,N+1), super_step_2, 'g.-', label="nu=0.01")
plt.plot(range(1,N+1), super_step_3, 'b.-', label="nu=1")
plt.plot(range(1,N+1), super_step_4, 'y.-', label="nu=0.000001")
plt.plot(range(1,N+1), [delta_t_expl*x*x for x in range(1,N+1)], 'k--', label="delta_t_expl*N^2")
plt.legend()
#plt.show()
plt.savefig("../generated/sts_tau.png")