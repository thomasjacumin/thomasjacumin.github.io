import numpy as np
import matplotlib.pyplot as plt

from DiffusionProblemLOD import DiffusionProblemLOD
from util import norm, computeDeltatExpl

# Mesh
NFine = np.array([12, 12])
NCoarse = np.array([3,3])
# forcing term
def f(t):
	res = np.zeros(np.prod(NCoarse+1))
	if t <= 0.002:
		res = np.ones(np.prod(NCoarse+1))
	return res;
# initial condition
u_0 = lambda X: np.zeros(np.prod(X+1))

# problem setting
alpha = 0.01
beta  = 200.

delta_t_expl, triangle_size = computeDeltatExpl(NFine, beta)
delta_t = delta_t_expl
t_max   = 1.

problemLOD = DiffusionProblemLOD(NFine, NCoarse)
problemLOD.generateRandCoeff(alpha, beta)
lod_basis, fem_basis = problemLOD.assembleMatrices()
problemLOD.f = f(0)

# Initialize the simulation
xFullLOD = u_0(NCoarse)
# Simulation's loop
nb_loop = int(t_max / delta_t)
for n in range(1, nb_loop):
	t=n*delta_t
	problemLOD.f = f(t)
	xFullLOD = problemLOD.solveStep(xFullLOD, delta_t)

	# plot solution
	plt.figure(0)
	plt.clf()
	plt.imshow((lod_basis*xFullLOD).reshape(NFine+1) )
	plt.title("solution at t=" + str(t*10**6) + "us") 
	plt.colorbar()
	plt.draw()
	plt.pause(0.001)